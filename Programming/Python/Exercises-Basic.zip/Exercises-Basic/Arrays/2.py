'''Write a Python program to append a new item to the end of the array.'''

A = [1,2,'e','r',5]
A.append(6);
print (A)
