'''Write a Python program to create an array of 5 integers and display the array items.
Access individual element through indexes.'''

"""Rough Work"""

import numpy as np

array1=np.array([1,2,3,4,5])

print(array1)
