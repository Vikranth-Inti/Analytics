'''Write a Python program to get the Python version you are using.'''


import sys
print(sys.version)
