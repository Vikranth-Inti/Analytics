'''Write a Python program to count the number 4 in a given list.'''

lst=str(input("Please enter list items by space : "))
lst=lst.split(' ')
print(lst.count('4'))
    
