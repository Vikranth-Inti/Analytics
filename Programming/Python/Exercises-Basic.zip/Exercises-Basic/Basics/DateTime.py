'''Write a Python program to display the current date and time.'''

from datetime import date
from datetime import time
from datetime import datetime
Tdate=date.today()
print(Tdate)
Tnow=datetime.now()
print(Tnow)
