'''Write a Python program which accepts the radius of a circle from the user and compute the area.'''

radius=float(input("Please enter the radius of  circle : "))
area=float(22/7)*radius**2
area=str(area)
print("Area of the given circle is : "+area)
