'''Write a Python program to display the first and last colors from the following list. 
color_list = ["Red","Green","White" ,"Black"]'''

color_list=["red","green","white","black"]
print("Given color list is : "+str(color_list))
length=len(color_list)
print("First color of the list is : "+str(color_list[0]))
print("Last color of the list is : "+str(color_list[length-1]))
