Python Tuple [ 24 exercises with solution]
[An editor is available at the bottom of the page to write and execute the scripts.]

1. Write a Python program to create a tuple. Go to the editor

Click me to see the sample solution

2. Write a Python program to create a tuple with different data types. Go to the editor

Click me to see the sample solution

3. Write a Python program to create a tuple with numbers and print one item. Go to the editor

Click me to see the sample solution

4. Write a Python program to unpack a tuple in several variables. Go to the editor

Click me to see the sample solution

5. Write a Python program to add an item in a tuple. Go to the editor

Click me to see the sample solution

6. Write a Python program to convert a tuple to a string. Go to the editor

Click me to see the sample solution

7. Write a Python program to get the 4th element and 4th element from last of a tuple. Go to the editor

Click me to see the sample solution

8. Write a Python program to create the colon of a tuple. Go to the editor

Click me to see the sample solution

9. Write a Python program to find the repeated items of a tuple. Go to the editor

Click me to see the sample solution

10. Write a Python program to check whether an element exists within a tuple. Go to the editor

Click me to see the sample solution

11. Write a Python program to convert a list to a tuple. Go to the editor

Click me to see the sample solution

12. Write a Python program to remove an item from a tuple. Go to the editor

Click me to see the sample solution

13. Write a Python program to slice a tuple. Go to the editor

Click me to see the sample solution

14. Write a Python program to find the index of an item of a tuple. Go to the editor

Click me to see the sample solution

15. Write a Python program to find the length of a tuple. Go to the editor

Click me to see the sample solution

16. Write a Python program to convert a tuple to a dictionary. Go to the editor

Click me to see the sample solution

17. Write a Python program to unzip a list of tuples into individual lists. Go to the editor

Click me to see the sample solution

18. Write a Python program to reverse a tuple. Go to the editor

Click me to see the sample solution

19. Write a Python program to convert a list of tuples into a dictionary. Go to the editor

Click me to see the sample solution

20. Write a Python program to print a tuple with string formatting. Go to the editor
Sample tuple : (100, 200, 300)
Output : This is a tuple (100, 200, 300)

Click me to see the sample solution

21. Write a Python program to replace last value of tuples in a list. Go to the editor
Sample list: [(10, 20, 40), (40, 50, 60), (70, 80, 90)]
Expected Output: [(10, 20, 100), (40, 50, 100), (70, 80, 100)]

Click me to see the sample solution

22. Write a Python program to remove an empty tuple(s) from a list of tuples. Go to the editor
Sample data: [(), (), ('',), ('a', 'b'), ('a', 'b', 'c'), ('d')]
Expected output: [('',), ('a', 'b'), ('a', 'b', 'c'), 'd']

Click me to see the sample solution

23. Write a Python program to sort a tuple by its float element. Go to the editor
Sample data: [('item1', '12.20'), ('item2', '15.10'), ('item3', '24.5')]
Expected Output: [('item3', '24.5'), ('item2', '15.10'), ('item1', '12.20')]

Click me to see the sample solution

24. Write a Python program to count the elements in a list until an element is a tuple. Go to the editor

Click me to see the sample solution
