Python Mini Projects
1. Create a Python project to get the value of Pi to n number of decimal places.
Note: Input a number and the program will generate PI to the 'nth digit

Click me to see the sample solution

2. Create a Python project to get the value of e to n number of decimal places.
Note: Input a number and the program will generate e to the 'nth digit

Click me to see the sample solution

3. Create a Python project to guess a number that has randomly selected.

Click me to see the sample solution

4. Create a Python project that prints out every line of the song "99 bottles of beer on the wall." Note: Try to use a built in function instead of manually type all the lines. 

Click me to see the sample solution

5. Create a Python project of a Magic 8 Ball which is a toy used for fortune-telling or seeking advice.

Allow the user to input their question.
Show an in progress message.
Create 10/20 responses, and show a random response.
Allow the user to ask another question/advice or quit the game.
Click me to see the sample solution
