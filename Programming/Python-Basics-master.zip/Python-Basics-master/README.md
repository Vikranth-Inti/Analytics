## Python-Basics

This repository is for beginners learning basic python. It can be used as resource of extra exercises along with a Python text book, or official Python tuotrial.

I request you to fork or clone this repository and provide alternate code to existing solutions.

Thank you.
