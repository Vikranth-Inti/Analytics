'''Write a Python program which accepts a sequence of comma-separated numbers
from user and generate a list and a tuple with those numbers.'''

NumList=input("Enter numbers separated by space : ")
print("List of given numbers is : "+NumList)
print("Tuple of given numbers is : "+str(tuple(NumList)))
