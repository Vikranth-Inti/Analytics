'''Write a Python program that accepts an integer (n) and computes the value of n+nn+nnn'''

n=float(input("Please enter a number : "))
print("The required value is : "+str(n+n*n+n**3))
