Pandas Movies Data Analysis [17 exercises with solution]
1. Write a Python Pandas program to get the columns of the DataFrame (movies_metadata.csv file). Go to the editor
Click me to see the sample solution

2. Write a Pandas program to get the information of the DataFrame (movies_metadata.csv file)including data types and memory usage. Go to the editor
Click me to see the sample solution

3. Write a Pandas program to get the details of the thrid movie of the DataFrame (movies_metadata.csv file). Go to the editor
Click me to see the sample solution

4. Write a Pandas program to count the number of rows and columns of the DataFrame (movies_metadata.csv file). Go to the editor
Click me to see the sample solution

5. Write a Pandas program to get the details of the columns title and genres of the DataFrame. Go to the editor
Click me to see the sample solution

6. Write a Pandas program to get the details of the movie with title 'Grumpier Old Men'. Go to the editor
Click me to see the sample solution

7. Write a Pandas program to get the details of  fifth movie of the DataFrame. Go to the editor
Click me to see the sample solution

8. Write a Pandas program to create a smaller dataframe with a subset of all features. Go to the editor
Click me to see the sample solution

9. Write a Pandas program to display the first 10 rows of the DataFrame. Go to the editor
Click me to see the sample solution

10. Write a Pandas program to sort the DataFrame based on release_date. Go to the editor
Click me to see the sample solution

11. Write a Pandas program to access those movies, released after 1995-01-01.Go to the editor
Click me to see the sample solution

12. Write a Pandas program to sort movies on runtime in descending order. Go to the editor
Click me to see the sample solution

13. Write a Pandas program to get those movies whose revenue more than 2 million and spent less than 1 million. Go to the editor
Click me to see the sample solution

14. Write a Pandas program to get the longest runtime and shortest runtime. Go to the editor
Click me to see the sample solution

15. Write a Pandas program to compute the calculate the number of votes garnered by the 70% movie. Go to the editor
Click me to see the sample solution

16. Write a Pandas program to display the movies (title, runtime) longer than 30 minutes and shorter than 360 minutes. Go to the editor
Click me to see the sample solution

17. Write a Pandas program to display the movies (title, number of votes) that received specified number of votes Go to the editor
Click me to see the sample solution
