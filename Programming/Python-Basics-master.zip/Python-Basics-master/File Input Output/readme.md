Python File Input Output[17 exercises with solution]
[An editor is available at the bottom of the page to write and execute the scripts.]

1. Write a Python program to read an entire text file. Go to the editor
Click me to see the sample solution

2. Write a Python program to read first n lines of a file. Go to the editor
Click me to see the sample solution

3. Write a Python program to append text to a file and display the text. Go to the editor
Click me to see the sample solution

4. Write a Python program to read last n lines of a file. Go to the editor
Click me to see the sample solution

5. Write a Python program to read a file line by line and store it into a list. Go to the editor 
Click me to see the sample solution

6. Write a Python program to read a file line by line store it into a variable. Go to the editor 
Click me to see the sample solution

7. Write a Python program to read a file line by line store it into an array. Go to the editor
Click me to see the sample solution

8. Write a python program to find the longest words. Go to the editor
Click me to see the sample solution

9. Write a Python program to count the number of lines in a text file. Go to the editor
Click me to see the sample solution

10. Write a Python program to count the frequency of words in a file. Go to the editor
Click me to see the sample solution

11. Write a Python program to get the file size of a plain file. Go to the editor
Click me to see the sample solution

12. Write a Python program to write a list to a file. Go to the editor
Click me to see the sample solution

13. Write a Python program to copy the contents of a file to another file . Go to the editor
Click me to see the sample solution

14. Write a Python program to combine each line from first file with the corresponding line in second file. Go to the editor
Click me to see the sample solution

15. Write a Python program to read a random line from a file. Go to the editor
Click me to see the sample solution

16. Write a Python program to assess if a file is closed or not. Go to the editor
Click me to see the sample solution

17. Write a Python program to remove newline characters from a file. Go to the editor
Click me to see the sample solution
