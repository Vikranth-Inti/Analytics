1. Write a Python program to search the Street address, name from a given location information using Nominatim API and GeoPy package. Go to the editor 
Click me to see the sample solution

2. Write a Python program to search the country name from given state name using Nominatim API and GeoPy package. Go to the editor 
Click me to see the sample solution

3. Write a Python program to find the details of a given zip code using Nominatim API and GeoPy package. Go to the editor 
Click me to see the sample solution

4. Write a Python program to find the latitude and longitude of a given location using Nominatim API and GeoPy package. Go to the editor 
Click me to see the sample solution

5. Write a Python program to find the location address of a specified latitude and longitude using Nominatim API and Geopy package. Go to the editor 
Click me to see the sample solution

6. Write a Python function to get the city, state and country name of a specified latitude and longitude using Nominatim API and Geopy package. Go to the editor 
Click me to see the sample solution

7. Write a Python program to calculate the distance between London and New York city. Go to the editor 
Click me to see the sample solution
